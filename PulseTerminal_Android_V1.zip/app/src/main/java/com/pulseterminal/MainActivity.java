package com.pulseterminal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
  int navy=Color.rgb(11,18,32), bg=Color.rgb(245,247,250), white=Color.WHITE, text=Color.rgb(16,24,40), muted=Color.rgb(102,112,133);
  LinearLayout root, content;

  TextView tv(String s,int sp,boolean bold){
    TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(text);
    t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setPadding(14,10,14,10); return t;
  }
  TextView card(String title,String value,String change){
    LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(8,8,8,8);
    TextView a=tv(title,12,false); a.setTextColor(muted); box.addView(a);
    box.addView(tv(value,21,true));
    TextView c=tv(change,12,true); c.setTextColor(change.startsWith("-")?Color.rgb(217,45,32):Color.rgb(7,148,85)); box.addView(c);
    box.setBackgroundColor(white); return wrap(box,0,0,8,8);
  }
  View wrap(View v,int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(l,t,r,b); v.setLayoutParams(p); return v; }

  @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }

  void build(){
    root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
    TextView top=tv("PULSE TERMINAL   •   LIVE",20,true); top.setTextColor(Color.WHITE); top.setBackgroundColor(navy); top.setPadding(18,22,12,22); root.addView(top);
    ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(12,14,12,24); sv.addView(content); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

    content.addView(tv("Good Morning, Trader",25,true));
    TextView sub=tv("Personal Market Intelligence • India",13,false); sub.setTextColor(muted); content.addView(sub);

    LinearLayout row=new LinearLayout(this); row.setPadding(0,12,0,4);
    row.addView(card("GIFT NIFTY","26,184","+0.32%")); row.addView(card("NIFTY 50","26,074","-0.21%"));
    content.addView(row);
    row=new LinearLayout(this); row.setPadding(0,4,0,4);
    row.addView(card("BANK NIFTY","59,418","-0.38%")); row.addView(card("INDIA VIX","14.82","+3.10%"));
    content.addView(row);

    addHeader("AI MARKET BIAS");
    TextView bias=tv("🟠  MILDLY CAUTIOUS

Illustrative score: 68/100
Global signals are mixed. Monitor crude, USD, US yields and Asian direction before the Indian open.",15,false);
    bias.setBackgroundColor(white); content.addView(bias);

    addHeader("GLOBAL PULSE");
    addRows("Nasdaq                         +0.41%","S&P 500                       +0.28%","Nikkei                           -0.54%","Brent Crude                  -1.12%");

    addHeader("NEWS INTELLIGENCE");
    addNews("HIGH IMPACT  •  US macro data keeps global yields in focus","Potential India linkage: USD, foreign flows and valuation multiples.");
    addNews("MEDIUM  •  Crude oil volatility remains a key India variable","Can affect import bill, INR and inflation-sensitive sectors.");
    addNews("MEDIUM  •  Asian equities are mixed","Could influence early risk appetite and sector rotation.");

    addHeader("TODAY'S CATALYSTS");
    addRows("India macro release                 HIGH","US economic data                    HIGH","Central bank speech                  MED","Major earnings                       MED");

    addHeader("OPTIONS RADAR");
    addRows("NIFTY   ATM 26,100   IV 12.8%   PCR 0.96","BANKNIFTY   ATM 59,400   IV 14.6%   PCR 0.91");

    TextView foot=tv("V1 Android prototype • Demo data. Live feeds and AI services are next.",11,false); foot.setTextColor(muted); content.addView(foot);
    setContentView(root);
  }
  void addHeader(String s){ TextView h=tv(s,13,true); h.setTextColor(Color.rgb(23,92,211)); h.setPadding(4,18,4,8); content.addView(h); }
  void addRows(String... ss){ for(String s:ss){ TextView r=tv(s,14,false); r.setBackgroundColor(white); content.addView(r,new LinearLayout.LayoutParams(-1,-2)); } }
  void addNews(String a,String b){ TextView n=tv(a+"\n"+b,14,false); n.setBackgroundColor(white); n.setPadding(14,14,14,14); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,3,0,3);content.addView(n,p); }
}
