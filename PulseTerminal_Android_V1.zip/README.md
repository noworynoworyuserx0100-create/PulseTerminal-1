# Pulse Terminal — Android V1

This is the first native Android prototype for the personal Mini-Bloomberg-style trading cockpit.

## Build
Open this folder in Android Studio, let Gradle sync, then Run on an Android device/emulator.

## Current V1
- Morning cockpit
- GIFT NIFTY / NIFTY / BANKNIFTY / VIX cards
- AI market-bias placeholder
- Global pulse
- News intelligence
- Economic catalysts
- Options radar

All market numbers are demo values. Live/licensed market and news data APIs are intentionally not embedded yet.

## Next
Backend + licensed market feeds + news ingestion + economic calendar + AI impact engine + alerts + options chain + journal.
